<?php
/**  Core_Modules  **/

/* Define library CORE MODULES path */


$allowedModules = array(
    'vc_icons_loader',
);


fixar_load_modules($allowedModules);



?>