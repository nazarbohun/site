<?php

    /* Include main framework file */
    require_once( get_template_directory().'/library/loader.php' );
?>
