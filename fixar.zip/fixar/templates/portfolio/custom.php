<?php
/*** Single Portfolio Custom template. */

?>
<div class="portfolio-custom">
	<div class="row">
		<div class="col-md-12">
			<div class="portfolio-custom-content">
				<?php the_content(); ?>
			</div>
		</div>
	</div>
</div>